
let captura= () =>{ //Funcion que devuelve lo que se introduce en Concepto
    return  document.querySelector("#concepto").value;
    
}
let clsInputs =() =>{ //Est funcion limpia formulario despues del submit
    document.querySelector("#formTarjeta").reset();
}

let asignaConcepto = () =>{
    const textConcepto =document.querySelectorAll(".concept"); 
    textConcepto[textConcepto.length-1].innerText =captura();
};


let asignaEntraSalidaDebeHaber =() =>{
    const inOrOut= document.querySelector("#inorout");
    const valor =inOrOut.value;
    const numEntrada= document.querySelectorAll(".in");
    const numSalida= document.querySelectorAll(".out");
    const valorDeUnidades= document.querySelector("#numUnidades").value;
    const valorDePu =document.querySelector("#presUnidad").value;
    const numDebe = document.querySelectorAll(".debe");
    const numHaber = document.querySelectorAll(".haber");
    const totalDeIngresos=parseInt(valorDeUnidades*valorDePu);

    if (valor==1){
        numEntrada[numEntrada.length-1].innerText=valorDeUnidades;
        numSalida[numSalida.length-1].innerText= 0;
        numDebe[numDebe.length-1].innerText = " $ " + totalDeIngresos;
        numHaber[numHaber.length-1].innerText=" $ " + 0;
       
    }
    else{
        numSalida[numSalida.length-1].innerText=valorDeUnidades;
        numEntrada[numEntrada.length-1].innerText= 0;
        numDebe[numDebe.length-1].innerText=" $ " + 0;
        numHaber[numHaber.length-1].innerText= " $ "+ totalDeIngresos;
        
    }
    
    

};
let asignaUS = ()=>{
    const numUnidades = document.querySelectorAll(".us");
    numUnidades[numUnidades.length-1].innerText = document.querySelector("#numUnidades").value;
};
let asignaPU = ()=>{
    const numPrecio = document.querySelectorAll(".pu");
    numPrecio[numPrecio.length-1].innerText = " $ " + document.querySelector("#presUnidad").value;
};

let asignaExistenciasYSaldo = () => {
    const inOrOut= document.querySelector("#inorout");
    const valor =parseInt(inOrOut.value);
    const numStock =document.querySelectorAll(".stock");
    const valorDeUnidades= document.querySelector("#numUnidades").value;
    const valorDebe =document.querySelectorAll(".debe");
    const valorHaber=document.querySelectorAll(".haber");
    const numSaldo = document.querySelectorAll(".balance");
    let numDebe = parseInt(valorDebe[valorDebe.length-1].textContent.slice(2));
    let numHaber =parseInt(valorHaber[valorHaber.length-1].textContent.slice(2));
    
    // console.log(typeof numDebe,numDebe, typeof numHaber, numHaber);
    let celdaAnteriorBalance = numSaldo[numSaldo.length-2];
    let numAnteriorBalance = numSaldo.length > 1?parseInt(celdaAnteriorBalance.textContent.slice(3)):0;
    let numDeUnidades =parseInt(valorDeUnidades);
    let celdaAnterior= numStock[numStock.length-2];
    let numDeUnidadesAnterior=numStock.length >1?parseInt(celdaAnterior.textContent):0;
    if(valor==1 && (numStock.length==1 || numSaldo==1)){
        numStock[0].innerText = numDeUnidades;
        numSaldo[0].innerText = " $ " + (numDebe-numHaber);
    }
    else if (valor ==1){
        numStock[numStock.length-1].innerText = numDeUnidadesAnterior + numDeUnidades;
        numSaldo[numSaldo.length-1].innerText =" $ " + (numAnteriorBalance + numDebe);

        
    }
    else{
        numStock[numStock.length-1].innerText = numDeUnidadesAnterior - numDeUnidades;
        numSaldo[numSaldo.length-1].innerText =" $ " + (numAnteriorBalance - numHaber);
    }
    
};




let creacionDeFilas = () =>{
    const nombreDeClases =["concept","in","out","stock","us","pu","debe","haber","balance"] ;  //Arreglo de clases para cada celda 
    let addFila =document.querySelector("tbody"); //Asigna a addFila como nodo padre el tbody
    let crearFila = document.createElement("tr"); //asigna a crearFila  la etiqueta de fila
    addFila.appendChild(crearFila); // se crea nueva fila en la tabla
    for(let i =0; i < 9; i++){        
        let celdas =crearFila.insertCell(i);// Crea 9 celdas enm cada fila
        celdas.className=nombreDeClases[i]; //asigna la su clase correspondiente en cada celda
        
    };
};





let newFila =document.querySelector("#btnNewFila"); // asigna a newFila la etiqueta del boton

newFila.onclick= () => {    

    creacionDeFilas();
    asignaConcepto();
    asignaUS();
    asignaPU();
    asignaEntraSalidaDebeHaber();
    asignaExistenciasYSaldo();
    clsInputs();
};

