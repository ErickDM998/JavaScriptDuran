//JavaScript Erick Duran
//Este programa generara a N cantidad de competidores, donde se les asignara un nombre y un tiempo de forma aleatoria a cada uno, para que al final salga una lista de como quedaron las posiciones 
// en una carrera 
class Competidor { 

    constructor(nombre){
    this.nombre = nombre.toUpperCase();
    this.tiempo =Math.trunc(Math.random()*(240-30)+30);  //Esta variable da un valor random del tiempo que se tardo cada competidor en realizar una carrea
} 
};


const x =parseInt(prompt("Ingrese la cantidad de participanrtes que habra en la carrera"))-1;

const competidores =[];

for (let i = 0; i <= x; i++ ){
    
    competidores.push(new Competidor (prompt(`Ingrese el nombre del participante No.${i+1}`)) );
};

console.log({competidores}); 



let  finalResults = competidores.slice();  //Esto clona el arreglo 
finalResults.sort((a , b) => { return a.tiempo - b.tiempo}); // Ordena el arreglo segun el tiempo que tiene cada competidor
console.log({finalResults});
console.log("LA LISTA DE GANADORES QUEDA DE LA SIGUIENTE MANERA");
for (let i = 0; i < finalResults.length; i++ ){
    
    console.log("Posicion : " +(i+1) + ", Nombre: " +finalResults[i].nombre + ", Tiempo:"+finalResults[i].tiempo); 
};
