// //Este simulador es sobre una venta de 10 productos los cuales podran tener diferentes descuentos dependiendo del tipo de cliente

// let opcion     = 0,
//     teclado    = 50,
//     mause      = 30,
//     monitor    = 350,
//     laptop     = 750,
//     pc         = 1000,
//     iva        = 0.16,
//     descuento  = 0;
// const subtotal = ( b ) =>{
//     let x;
//     if(b !=0){
//         x = x + b;     
//     }
//     else{
//         return x;
//     }       
//     };

// const total =( a ) =>{
    
// } ;


// do{
//     opcion=prompt("Ingrese el producto que desea agregar");
//     switch(opcion){
//         case "1":
//             subtotal(teclado);
//         break;

//         case "2":
//             subtotal(mause);
//         break;
        
//         case "3":
//             subtotal(monitor);
//         break;

//         case "4":
//             subtotal(laptop);
//         break;

//         case "5":
//             subtotal(pc);
//         break;

//         case "6":
//             alert(subtotal(0));
            
//         break;

//         default:
//             console.log("Valor incorrecto intente de nuevo")
//         break;
//     }

// }

// while(opcion!=9 );


//--------------------------------------------------------------------

// class Alumno  {
//     constructor (nombre ,promedio){
//         this.nombre = nombre;
//         this.promedio = promedio;
//     }
// }

// const alumno1  = [] new Alumno ;
// alumno1.nombre = 'Erick';
// alumno1.promedio=8.5;



// const alumnoX = [
//     {
//         nombre: nombresAlum(),
//         promedio: promedioAlum()
//     }
// ];
// const pedirNombre = () => {
//     return prompt("Ingrese el nombre del alumno");
// };
// const pedirPromedio = () => {
//     return prompt("Ingrese el promedio del alumno");
// };

const promedio = (obj) =>{
    let x=0;
    for ( let i=0; i< 5; i++){
        x= x + parseInt(obj[i].promedio); 
    }   
   
    
    return (x/5);
};
const revisarPromedio = (prom) =>{
    
        if(prom >100 || prom <0){
            alert("El promedio ingresado es incorrecto debe ser menor a 100 y mayor a 0");
            
            return  prompt(`Ingrese de el pomedio de forma correcta del alumn@`);
        }
        else{
            return prom;
        }
        
      
};

const alumnoX =[
    {
        alumno: "Juan",
        promedio: 0
    },
    {
        alumno: "Diego",
        promedio: 0
    },
    {
        alumno: "Jorge",
        promedio: 0
    },
    {
        alumno: "Diana",
        promedio: 0 
    },
    {
        alumno: "Mariana",
        promedio: 0 
    }
];

for(let i =0;i<5; i++){
    
    alumnoX[i].promedio=revisarPromedio(prompt(`Ingrese el promedio del alum@: ${alumnoX[i].alumno}`));
}

console.log(alumnoX);
console.log(promedio(alumnoX));
alert(`El promedio final de los alumnos es:  ${promedio(alumnoX)}`);

