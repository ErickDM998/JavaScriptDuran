/* Duran Medina Erick Alejandro
Primer Desafio entregrable

Ejercicio: Crea un algoritmo utilizando un ciclo

*/
function iniciarPrograma(){
let factorial=0,
    opcion=0,
    resultado=1,
    calificacion=0;

do{

  
    opcion=prompt("Ingrese el la opcion del menu que desea ejecutar: ");
    switch(opcion){

        case "1":
            factorial=prompt("Ingrese el numero para realizar su factorial: ");
            for(let i=0; i<factorial;i++){
                resultado=resultado*(i+1);
            }

            alert("El resultado  de "+factorial+"! es :"+resultado);

        break;
        case "2":
            calificacion=prompt("Ingrese la calificación del alumno");

            if(calificacion <= 100 && calificacion >=90){
                alert("La calificacion correspondiente a "+ calificacion + " es : Muy Bien (MB)");
            }

            else if(calificacion < 90 && calificacion >=74 ){
                alert("La calificacion correspondiente a "+ calificacion + " es : Bien (B)");
                
            }
            else if(calificacion < 74 && calificacion >=60){
                alert("La calificacion correspondiente a "+ calificacion + " es : suficiente (S)");
            }
            else if(calificacion < 60 && calificacion >= 0){
                alert("La calificacion correspondiente a "+ calificacion + " es : No Aprobado (NA)");
            }
            else {
                alert("El valor que intenta ingresar es incorrecto")
                
            }


        break;
        case "3":
            
            alert("Bye!!!!!!!!!");
        break;

        default:
            alert("Valor incorrecto intente de nuevo");
        break;

    }


}
while(opcion!=3);

}

//iniciarPrograma();