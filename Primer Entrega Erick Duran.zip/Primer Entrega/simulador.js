function iniciarJS(){

    //Este programa es para gestionar una tarjeta de almacen 
    class Transaccion{
        
        
    constructor(concept,inOrOut,units,price){
        this.concept =concept;  //Ingresa el concepto
        this.inOrOut =inOrOut==1?true:false; // Es para saber si es una entrada o salida        
        this.units   =units; //Ingresa las unidades que entren o salgan
        this.price   =price; // Falta determinar precio en el caso de que sean salidas, por que esto determinara el precio de salida conforme al metodo PEPS
    };
    
    
};


const tarjetaDeAlmacen = [];
let flujo,
stock=0,
debe=0,
haber=0,
saldo=0,
i=0;
do{
    
    tarjetaDeAlmacen.push(new Transaccion (prompt("Ingrese el nombre del concepto"),parseInt(prompt("Precione 1 si es entrada y 0 si es salida")), parseInt(prompt("Ingrese la cantidad de unidades")),parseFloat(prompt("Ingrese el precio unitario con decimales si es que los tiene"))));
    
    flujo=prompt("Si desea agregar alguna otra transaccion precione 1, sino precione 0")==1?true:false;

    stock = tarjetaDeAlmacen[i].inOrOut==true?(stock+tarjetaDeAlmacen[i].units):(stock-tarjetaDeAlmacen[i].units); //Acumula la cantidad de producto que hay en el inventario dependiendo si son entradas o salidas
    debe = tarjetaDeAlmacen[i].inOrOut==true?(debe+(tarjetaDeAlmacen[i].units*tarjetaDeAlmacen[i].price)):debe;//Calcula el debe en caso de ser entrada
    haber = tarjetaDeAlmacen[i].inOrOut==false?(haber+(tarjetaDeAlmacen[i].units*tarjetaDeAlmacen[i].price)):haber; //Calcula el haber en caso de ser salidas
    saldo=debe-haber;
    
    i++;
}while(flujo===true); //Cuando el usuario ya no quiera ingresar mas datos se rompe el ciclo


console.log({x: tarjetaDeAlmacen});
console.log("Las existencias son: ",stock);
console.log("El Debe es: ",debe);
console.log("El Haber es: ",haber);
console.log("El saldo es: ",saldo);

};